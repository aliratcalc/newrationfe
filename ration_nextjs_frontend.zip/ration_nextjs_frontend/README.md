
# Ration Frontend

Bu proje bir Next.js uygulamasıdır. Rasyon hesaplama formu içerir.

## Kurulum

```
npm install
npm run dev
```

## Build

```
npm run build
npm start
```
